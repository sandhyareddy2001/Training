package springjunittesttry;

import org.junit.jupiter.api.Test;

public class TestCase1 {
	
	@Test
	public void test1() {
		System.out.println("TestCase1Test1");
	}

}
