package springjunittesttry;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class TestCase2 {

	@Test
	public void test2() {
		System.out.println("TestCase2Test2");
	}

}
