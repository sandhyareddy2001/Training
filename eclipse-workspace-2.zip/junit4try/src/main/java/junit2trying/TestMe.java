package junit2trying;


public class TestMe {
	public static int add(int a, int b) {
		return a+b;
	}
	
	
	
}