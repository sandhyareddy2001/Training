package junit2trying;

import org.junit.Test;

public class TestCase2 {

	@Test
	public void test2() {
		System.out.println("TestCase2 test2 method ");
	}

}
