package com.jerseyEmployee.project.EmployeeProj;

public class EmpServicesImpl {
	
	public Employee insertEmployee(){
		return null;
		
	}
	public Employee deleteEmployee(){
		return null;
		
	}
	public Employee searchEmployee(){
		return null;
		
	}
	

}
