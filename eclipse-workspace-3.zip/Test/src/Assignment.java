import java.util.*;
public class Assignment {
	void SumOdd() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the value of N: ");
		int N=sc.nextInt();
		if (N%2==0)
			N=N/2;
		else
			N=(N/2)+1;
		System.out.println(N*N);
		
	}
	void SumEven() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the size of the array: ");
		int size=sc.nextInt();
		int a[]=new int[size];
		for(int i=0;i<size;i++) {
			a[i]=sc.nextInt();
		}
		int sum=0,k=1;
		for(int i:a) {
			if (i%2==0) {
				k=0;
				sum=sum+i;
			}
		}
		if (k==1) {
			System.out.print("Sum of Even Numbers: "+-1);
		}
		else {
			System.out.print("Sum of Even Numbers: "+sum);
		}
		
	}
	
	void SumArr() {
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter the size of the array: ");
		int size=sc.nextInt();
		System.out.println("Enter the array: ");
		int a[]=new int[size];
		for(int i=0;i<size;i++) {
			a[i]=sc.nextInt();
		}
		System.out.println("Enter the num: ");
		int num=sc.nextInt();
		int sum=0;
		for(int i:a) {
			if (i>num) {
				sum=sum+i;
			}
		}
		int r=0, rem=0;
		System.out.println("Sum: "+sum);
		
		while(sum!=0)
		{
			rem=sum%10;
			r=r*10+rem;
			sum=sum/10;
		}
		System.out.println("Reverse of Sum: "+r);
		
	}
	
	void fiboSum() {
		Scanner sc=new Scanner(System.in);
		int num=sc.nextInt();
		
		int f=0, s=1,t,i=0,Sum=0;
		if (num==1){
			System.out.println(0);
			
		}
		else if (num==2) {
			System.out.println(1);
		}
		else {
			Sum=1;
			//System.out.println(0);
			//System.out.println(1);
		for(i=2;i<num;i++) {
			t=f+s;
			f=s;
			s=t;
			Sum=Sum+t;
			//System.out.println(t);
			
			
		}
		}
		
		
		System.out.println(Sum);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Assignment a=new Assignment();

		System.out.println("Enter 10 to STOP!");
		System.out.println("Enter the qs no.: ");
		Scanner sc=new Scanner(System.in);
		int e=sc.nextInt();
		
		while(e!=10) {
		switch(e){
		case 4:
			System.out.println("fiboSum");
			a.fiboSum();
			System.out.println("Enter the qs no.: ");
			e=sc.nextInt();
			
		case 1:
			System.out.println("SumArr");
			a.SumArr();
			System.out.println("Enter the qs no.: ");
			e=sc.nextInt();
		case 3:
			System.out.println("SumEven");
			a.SumEven();
			System.out.println("Enter the qs no.: ");
			e=sc.nextInt();
		case 2:
			System.out.println("Sum of all odd nums from to N");
			a.SumOdd();
			System.out.println("Enter the qs no.: ");
			e=sc.nextInt();
		}

			
		
		}
		

	}

}
