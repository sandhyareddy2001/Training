import java.util.function.Predicate;
import java.util.Scanner;
class Area{
	int l;
	int b;
	Area(int l, int b){
		this.l=l;
		this.b=b;
	}
}

class Acc{
	String user;
	String pass;
	Acc(String user, String pass){
		super();
		this.user=user;
		this.pass=pass;
		
	}
	
}
public class PredicateUserTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Predicate <Acc> p= t->(t.user=="Admin" && t.pass=="1234");
		Predicate <Acc> p1= y->(y.user.charAt(0)=='A' && y.pass.charAt(1)=='2');
		
		Acc a= new Acc("Admin","1234");
		
		System.out.println(p.test(a));
		System.out.println(p1.test(a));
		System.out.println("\n");
		Scanner sc= new Scanner(System.in);
		
		System.out.print(" Length: ");
		int n = sc.nextInt();
		System.out.print(" Breadth: ");
		int m = sc.nextInt();
		
		
		Area q= new Area(n,m);
		
		Predicate <Area> e= u->(u.l*u.b>100);
		
		if (e.test(q))
			System.out.println("Big Rectangle!!!");
		else
			System.out.println("Small Rectangle!!!");
		

	}

}
