class Addr{
	int doorNo;
	String street;
	String landmark;
	
	public Addr(int dno, String s, String l) {
		this.doorNo=dno;
		this.street=s;
		this.landmark=l;
	}
}

class Employee{
	int id;
	String addr;
	String ReportsTo;
	int doj;
	
	void Showaddr(Addr a) {
		System.out.println("Door No. "+a.doorNo);
		System.out.println("street: "+a.street);
		System.out.println("Landmark. "+a.landmark);
		
	}
}
public class HasRelationship {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Addr a= new Addr(1234, "Gandhi Nagar", "State Bank of India");
		Employee e=new Employee();
		e.Showaddr(a);
		

	}

}
