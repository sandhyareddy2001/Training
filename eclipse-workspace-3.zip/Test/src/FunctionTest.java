import java.util.function.Function;

class Circle{
	int rad;
	double circumference;
	double area;
	int diameter;
	Circle(int r){
		this.rad=r;
		this.circumference=2*3.14*r;
		this.area=3.14*r*r;
		this.diameter=2*r;
	}
}

public class FunctionTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Function <Integer,String> f=n->"The radius is "+n;
		System.out.println(f.apply(8));
		
		Function <Integer,String> f1=n->"The area is "+(3.14*n*n);
		System.out.println(f1.apply(8));
		
		Function <Integer,String> f2=n->"The number is "+n;
		System.out.println(f2.apply(8));
		
		Circle c= new Circle(10);
		System.out.println("\n");
		Function <Circle, String> f3=n->{
			String q="The circle with radius "+n.rad+" has \n 1. Circumference as "+n.circumference+"\n 2. Diameter as "+n.diameter+"\n 3. Area as "+n.area;
			return q;
			
		};
		System.out.println(f3.apply(c));

	}

}
