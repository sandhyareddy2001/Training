
public class StringQs {
	static String reverseString(String s) {
		String str="";
		for(int i=s.length()-1;i>=0;i--) {
			str=str+s.charAt(i);
		}
		return str;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(reverseString("Sandhya"));
		String str="Sandhya";
		System.out.println(str.substring(0,4));
		String a="S_P_L_I_T";
		String b="_";
		String []c=a.split(b);
		
		for(String i:c) {System.out.println(i);}
		
		String m="Mo7767ney i877s a97 ba8866d ma7657ster7766 but8767 a8789989n 0989678e234234xcel78867lent789890 se6785678rvant";
		System.out.println("BEFORE: "+m);
		String pat="[0-9]";
		System.out.println("AFTER: "+m.replaceAll(pat, ""));

	}

}
