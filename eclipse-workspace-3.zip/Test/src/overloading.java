
public class overloading {
	void me(int a) {
		System.out.println("Iam an integer "+a);
	}
	void me(char a) {
		System.out.println("Iam a character "+a);
	}
	
	
	public static void main(String[] args) {
		overloading w=new overloading();
		w.me(7);
		w.me('r');
	}

}





