import java.util.function.Function;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.Scanner;
//import java.util.function.Supplier;


class Student{
	String name;
	int marks;
	String result;
	Student(int marks, String name){
		this.marks=marks;
		this.name=name;
	}
}
public class AllFourInOne {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		System.out.print("Name of the Student: ");
		String Name= sc.nextLine();
		System.out.print("Marks Obtained by "+Name+": ");
		int Marks=sc.nextInt();
		Student s= new Student(Marks,Name);
		
		///////////////////////////////////////////////
		Predicate <Student> p= n->n.marks>50;
		//System.out.print(p.negate().test(s));
		///////////////////////////////////////////////
		Function <Student,String> f= n->{
			if(n.marks<80) {
				n.result="Second Class";
				String g="Result of "+n.name+" is "+n.result;
				return g;
			}
			else {
				n.result="First Class";
				String g="Result of "+n.name+" is "+n.result;
				return g;
			}
		};
		
		//////////////////////////////////////////////////
		Consumer <Student> c=n->{
			if (p.test(s))
				System.out.println(f.apply(s));
			else {
				n.result="Fail";
				System.out.println("Result of "+n.name+" is "+n.result);
			}
		};
		
		///////////////////////////////////////////////////
		c.accept(s);
		
		

	}

}
