class Account{
	
}

class SavingsAcc extends Account{
	
}

class CurrentAcc extends Account{
	
}
public class Inheritance2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
