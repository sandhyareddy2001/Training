package Collections;
import java.util.*;
import java.util.function.Consumer;

class Stu{
	String name;
	int Grade;
	public Stu(String name, int Grade) {
		this.name=name;
		this.Grade=Grade;
	}
	@Override
	public String toString() {
		return "name: "+this.name+" Grade: "+this.Grade;
	}
}
public class ListTry {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		LinkedList <Stu> s=new LinkedList();
		Stu s1= new Stu("Lisa",10);s.add(s1);
		Stu s2= new Stu("Jisoo",5);s.add(s2);
		Stu s3= new Stu("Rose",3);s.add(s3);
		Stu s4= new Stu("Jennie",4);s.add(s4);
		
		System.out.println("Iterator Print: ");
		Iterator itr= s.iterator();
		while(itr.hasNext())
			System.out.println(itr.next());
		System.out.println("#################################################");
		
		
		System.out.println("Normal For()");
		for(Stu i:s)
			System.out.println(i);
		System.out.println("#################################################");
		
		
		Consumer <Stu> cons= n->System.out.println(n);
		System.out.println("ForEach() Print: ");
		s.forEach(cons);
		System.out.println("#################################################");
		
		
/*		
		ArrayList a=new ArrayList();
		a.add("Sandhya");
		a.add(4);
		System.out.println(a);
		
		ArrayList a1=new ArrayList();
		a1.add("id");
		a1.addAll(a);
		System.out.println(a1);
		
		a.remove(a1);
		System.out.println(a);
		System.out.println(a1.contains(a1));
		
		
		Consumer <Integer> c= n->System.out.println(n*2);
		LinkedList l= new LinkedList();
		l.add(2);
		l.add(3);
		l.add(7);
		l.add(6);
		l.forEach(c);
		
		
	
	*/
	}

}
