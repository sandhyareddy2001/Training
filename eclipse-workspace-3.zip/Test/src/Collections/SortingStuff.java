package Collections;

import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;

class Employeee{
	String name;
	int rank;
	
	@Override
	public String toString() {
		return "name: "+this.name+" Rank: "+this.rank+"\n";
	}

	Employeee(String name, int rank){
		this.name=name;
		this.rank=rank;
	}
}

class SortRank implements Comparator<Employeee>{
	@Override
	public int compare(Employeee e1, Employeee e2) {
		// TODO Auto-generated method stub
		if (e1.rank>e2.rank)
			return 1;
		else if (e1.rank<e2.rank)
			return -1;
		else
			return 0;
	}
	
}
public class SortingStuff {
	public static void main(String[] args) {
		Employeee e1=new Employeee("Rohith",3);
		Employeee e2=new Employeee("Sandhya",1);
		Employeee e3=new Employeee("Ramya",2);
		Employeee e4=new Employeee("Revathy",10);
		
		LinkedList <Employeee> e=new LinkedList();
		e.add(e1);
		e.add(e2);
		e.add(e3);
		e.add(e4);
		
		SortRank sr=new SortRank();
		Collections.sort(e,sr);
		System.out.print(e);
		//System.out.println(sr.compare(e1, e2));
		
		Collections.sort(e,(s1,s2)->s1.name.compareTo(s2.name));
		System.out.print(e);
		
	}

}
