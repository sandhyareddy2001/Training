package Collections;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;


class Stdent{
	int marks;
	String name;
	Stdent(int marks, String name){
		this.marks=marks;
		this.name=name;
	}
	@Override
	public String toString() {
		return this.name+" "+this.marks;
	}
	
	
}
public class StreamsTry {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayList a= new ArrayList();
		a.add(7);
		a.add(1);
		a.add(4);
		a.add(9);a.add(0);
		Predicate <Stdent> p=n->n.marks<50;
		Function <Stdent, Stdent> f=n->{
			n.marks=n.marks+10;
			return n;
		};
		Comparator <Stdent> c=(s1,s2)->s1.name.compareTo(s2.name);
		Stdent s1=new Stdent(50,"gfds");
		Stdent s2=new Stdent(78,"vbhbvbcdh");
		Stdent s3=new Stdent(25,"oplolpl");
		Stdent s4=new Stdent(90,"ewqew");
		Stdent s5=new Stdent(35,"xzcxcxcx");
		List<Stdent> l= new ArrayList();
		l.add(s1);
		l.add(s2);
		l.add(s3);l.add(s4);l.add(s5);
		Stream<Stdent> s=l.stream();
		List<Stdent> L=(List<Stdent>) s.filter(p).map(f).collect(Collectors.toList());
		Stream<Stdent> sn=l.stream();
		System.out.println(l);
		System.out.println("Count:" +sn.filter(p).map(f).count());
		System.out.println(L);
		Stream<Stdent> sc=l.stream();
		System.out.println(sc.sorted(c).collect(Collectors.toList()));
		//Stream s1=s.filter(p);
		//List <Integer>o= (List <Integer>) s.filter(p).collect(Collectors.toList());
		//System.out.print(o);
		
		
		

	}

}
