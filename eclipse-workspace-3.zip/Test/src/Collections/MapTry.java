package Collections;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;


public class MapTry {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Map <Integer, String>s= new HashMap();
		s.put(1,"Sandhya");
		s.put(2, "Renu");
		s.put(3, "Rekhana");
		s.put(4, "Sandeep");
		s.put(5, "Sanjay");
		s.put(6, "Swaroop");
		
		System.out.println(s.keySet());
		System.out.println(s.values());
		
		System.out.println("");
		Set set=s.entrySet();
		Iterator itr= set.iterator();
		while(itr.hasNext()) {
			Map.Entry entry=(Map.Entry) itr.next();
			System.out.println(entry.getKey()+" "+entry.getValue());
		}
		System.out.println("Names Starting with 'S' ");
		Collection<String> v= s.values();
		System.out.println(v);
		for(String i:v) {
			if(i.charAt(0)=='S')
				System.out.println(i);
		}
		

	}

}
