package Collections;

import java.util.LinkedList;
import java.util.TreeSet;

class Su implements Comparable<Su>{
	String name;
	int Grade;
	public Su(String name, int Grade) {
		this.name=name;
		this.Grade=Grade;
	}
	@Override
	public String toString() {
		return this.name+"  "+this.Grade;
	}
	@Override
	public int compareTo(Su s) {
		// TODO Auto-generated method stub
		return this.name.compareTo(s.name);
	}
}


public class SetTry {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeSet <Su> s=new TreeSet();
		Su s1= new Su("Lisa",10);s.add(s1);
		Su s2= new Su("Jisoo",5);s.add(s2);
		Su s3= new Su("Rose",3);s.add(s3);
		Su s4= new Su("Jennie",4);s.add(s4);
		System.out.println(s);
		
		
	}

}
