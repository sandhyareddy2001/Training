package Collections;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

class Addresss{
	String dno;
	String street;
	String district;
	String state;
	
	@Override
	public String toString() {
		return "Address: \n Dno."+this.dno+"\n Street: "+this.street+"\n District: "+this.district+"\n State: "+this.state;
	}

	Addresss(String dno, String street, String district, String state){
		this.dno=dno;
		this.street=street;
		this.district=district;
		this.state=state;
	}
}
public class MapTry2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Addresss s= new Addresss("1-2-44/9","fed","gferfreg","Haryana");
		Addresss s1= new Addresss("5-1-09/1","sdwdw","ijhijh","Tamil Nadu");
		Addresss s2= new Addresss("6-7-34/5","vfevevcfe","cvbnvb","Jammu & Kashmir");
		Map <String, Addresss>mm= new HashMap();
		mm.put("Sandhya", s);
		mm.put("Priyanka", s1);
		mm.put("Rahul", s2);
		Set d=mm.entrySet();
		Iterator it= d.iterator();
		while(it.hasNext()) {
			Map.Entry entry= (Map.Entry)it.next();
			System.out.println(entry.getKey()+" "+entry.getValue());
			System.out.println("");
		}
		
		
		
		

	}

}
