package Collections;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Stream;

public class MinMaxTry {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Integer> y=new ArrayList();
		y.add(0);y.add(10);y.add(9);y.add(3);y.add(5);y.add(7);
		Comparator<Integer> c=(n1,n2)->n1.compareTo(n2);
		Stream s=y.stream();
		System.out.println(y.stream().min(c));
		System.out.println(y.stream().max(c));
		
		

	}

}
