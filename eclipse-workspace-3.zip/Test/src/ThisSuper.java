class A{
	A(char t){
		this();
		System.out.println("Parameterised A Constructor");
	}
	A(){
		System.out.println("A constructor");
	}
}

class B extends A{
	
	B(){
		super();
		System.out.println("B constructor");
	}
	
}
class C extends B{
	C(){
		super();
		System.out.println("C constructor");
	}
	
}
public class ThisSuper {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		C c= new C();
		A a= new A('d');
	}

}
