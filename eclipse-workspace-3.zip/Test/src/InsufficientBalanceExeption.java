
public class InsufficientBalanceExeption extends Exception {
	public InsufficientBalanceExeption() {
		super("Low Balance- Permission for withdrawal DENIED \nplease make sure you have a minimum of 5k in your account all the time! ");
	}
	

}
