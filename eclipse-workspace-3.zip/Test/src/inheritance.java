class Emp{
	int id;
	String addr;
	String ReportsTo;
	int doj;
}
class Developer extends Emp{
	int bonus;
	int salary;
	
	Developer(int id, String addr, String ReportsTo, int doj, int bonus, int salary){
		this.id=id;
		this.addr=addr;
		this.ReportsTo=ReportsTo;
		this.doj=doj;
		this.bonus=bonus;
		this.salary=salary;
		
		
		System.out.println("Developer Employee ID: "+this.id);
		System.out.println("Developer Employee address: "+this.addr);
		System.out.println("Developer Employee reports to: "+this.ReportsTo);
		System.out.println("Developer Employee date of joining: "+this.doj);
		System.out.println("Developer Employee bonus: "+this.bonus);
		System.out.println("Developer Employee salary: "+this.salary);
	}
	
	void showId(int id) {
		this.id=id;
		System.out.println("Id :"+this.id);
	}
	
}
public class inheritance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Developer d=new Developer(123,"India", "Vinesh",23, 70000, 1000000000);
		

	}

}
