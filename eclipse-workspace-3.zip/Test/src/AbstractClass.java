abstract class Currency{
	String currency;
	public abstract void setCurrency();
}

class India extends Currency{
	public void setCurrency() {
		currency="Rupee";
		System.out.println("Currency in India: "+currency);
	}
	
}

class SouthKorea extends Currency{
	public void setCurrency() {
		currency="Yens";
		System.out.println("Currency in Koria: "+currency);
	}
	
}
public class AbstractClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		India i= new India();
		SouthKorea s= new SouthKorea();
		
		i.setCurrency();
		s.setCurrency();

	}

}
