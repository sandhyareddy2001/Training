@FunctionalInterface
interface Maths{
	int area(int a, int b);
}

interface Printable{
	void print(int[] a);
}


public class Threadtest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Runnable f=()->System.out.println("IAm a ThReAd!!!");
		Thread t= new Thread(f);
		t.run();
		
		Maths m=(a,b)->a+b;
		System.out.println(m.area(12,34));
		
		Printable p=(a)->{for(int i:a)System.out.println(i);};
		int k[]= {1,2,3,4,5};
		p.print(k);
		
	}

}
