import java.util.function.*;
public class AllBisfnucsTest {

	public static void main(String[] args) {
		
		//////////////////////////////////////////////////////////////////////////////
		BiPredicate <String,Integer>p=(a,b)->b==a.length();
		System.out.println(p.test("Sandy", 5));
		////////////////////////////////////////////////////////////////////////////
		
		BiFunction <String, Integer, String> f= (a,b)->{
			if( a.length()==b)
				return "The String "+a.toUpperCase()+" contains "+b+" characters ";
			else
				return "The String "+a.toUpperCase()+" doesnt contains "+b+" characters ";
		};
		System.out.println(f.apply("hate", 4));
		
		///////////////////////////////////////////////////////////////////////////////////
		BiConsumer <String, Integer> c= (a,b)->{
			if( a.length()==b)
				System.out.println("The String "+a.toUpperCase()+" contains "+b+" characters ");
			else
				System.out.println("The String "+a.toUpperCase()+" doesnt contains "+b+" characters ");
		};
		
		c.accept("Consumer", 4);
		/////////////////////////////////////////////////////////////////////////////////////
	}

}
