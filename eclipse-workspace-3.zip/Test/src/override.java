class Q{
	int x,y;
	void show(int x, int y) {
		this.x=x;
		this.y=y;
		
		System.out.println("X= "+x);
		System.out.println("Y= "+y);
	}
}
class P extends Q{
	int x,y;
	void show(int x, int y) {
		this.x=x;
		this.y=y;
		
		System.out.println("X= "+super.x);
		System.out.println("Y= "+y);
	}
}
public class override {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Q q= new Q();
		P p= new P();
		
		q.show(10,20);
		p.show(40,50);

	}

}
