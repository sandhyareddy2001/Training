interface Animal{
	void sound();
	void food();
}

class Dog implements Animal{
	public void sound() {
		System.out.println("Dog barks");
	}
	
	public void food() {
		System.out.println("Dog is an amnivores animal");
	}
	
	
}

class Cat implements Animal{
	public void sound() {
		System.out.println("Cat meows");
	}
	
	public void food() {
		System.out.println("Cat is an amnivores animal");
	}
}

class Elephant implements Animal{
	public void sound() {
		System.out.println("Elephant rumbles like a trumpet");
	}
	
	public void food() {
		System.out.println("Elephant is a herbivores animal");
	}
}
public class InterfaceProgram {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Dog d= new Dog();
		Cat c= new Cat();
		Elephant e= new Elephant();
		d.sound();
		d.food();
		System.out.println("");
		c.sound();
		c.food();
		System.out.println("");
		e.sound();
		e.food();
		
		

	}

}
