import java.util.Scanner;

class BankUser{
	String name;
	int Withdraw;
	int Balance;
	BankUser(String name, int Balance) throws InsufficientBalanceExeption {
		this.name=name;
		this.Balance=Balance;
		System.out.println("Hi..."+this.name+" your account balance is "+this.Balance);
		System.out.println("Please enter the amount you want to withdraw: ");
		Scanner sc= new Scanner(System.in);
		this.Withdraw=sc.nextInt();
		
		if (this.Balance-this.Withdraw<5000) {
			throw new InsufficientBalanceExeption();
		}
	}
}
public class TestException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
		BankUser b=new BankUser("Rahul",6000);
		}
		catch( InsufficientBalanceExeption e){
			System.out.println(e);
		}
		
		System.out.println("Done");
		
	

	}

}
