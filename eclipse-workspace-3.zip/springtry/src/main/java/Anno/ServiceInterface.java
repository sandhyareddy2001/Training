package Anno;

public interface ServiceInterface {
	public String whatService();

}
